# Teamcenter Custom BOM Viewer

This is a mock project simulating a custom BOM (Bill of Materials) Viewer built as a Teamcenter customization. It demonstrates how to use Java for backend logic, integrate with a simulated PLM REST API, and render a lightweight web interface for engineering teams.

## Features
- Java-based backend simulating Teamcenter ITK calls
- Mock REST API (Python Flask)
- Frontend built with HTML/JavaScript for rendering BOM tree
- Modular codebase simulating Teamcenter customization patterns

## Tech Stack
- Java
- HTML/CSS/JS
- Python (for API simulation)

## For Demo Only
This project is intended for portfolio and demonstration purposes only. It does not contain any proprietary or confidential code.
