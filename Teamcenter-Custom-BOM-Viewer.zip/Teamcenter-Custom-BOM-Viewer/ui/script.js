fetch('/api/bom/1234')
    .then(response => response.json())
    .then(data => {
        const bomDiv = document.getElementById('bom');
        bomDiv.innerHTML = '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
    });
