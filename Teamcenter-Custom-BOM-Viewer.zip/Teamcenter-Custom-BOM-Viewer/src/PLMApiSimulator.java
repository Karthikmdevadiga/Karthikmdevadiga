public class PLMApiSimulator {
    public String getBOM(String itemId) {
        return "{ \"item_id\": \"" + itemId + "\", \"components\": [{\"name\": \"Component A\", \"qty\": 2}, {\"name\": \"Component B\", \"qty\": 4}] }";
    }
}
