from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/bom/<item_id>')
def get_bom(item_id):
    return jsonify({
        "item_id": item_id,
        "components": [
            {"name": "Component A", "qty": 2},
            {"name": "Component B", "qty": 4}
        ]
    })

if __name__ == '__main__':
    app.run(debug=True)
