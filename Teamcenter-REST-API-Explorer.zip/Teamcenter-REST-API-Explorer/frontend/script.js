function fetchItem() {
    fetch('/api/items/1001')
        .then(response => response.json())
        .then(data => {
            document.getElementById('output').innerText = JSON.stringify(data, null, 2);
        });
}

function fetchBOM() {
    fetch('/api/bom/1001')
        .then(response => response.json())
        .then(data => {
            document.getElementById('output').innerText = JSON.stringify(data, null, 2);
        });
}
