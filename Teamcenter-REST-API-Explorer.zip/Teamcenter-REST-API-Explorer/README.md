# Teamcenter REST API Explorer

This mock project simulates a frontend and backend interaction with Teamcenter-like REST APIs. It's intended to demonstrate REST integration and visualization of PLM data.

## Features
- Simulated REST API using Flask
- Frontend built with HTML and JavaScript
- Endpoints for item lookup and BOM display

## Tech Stack
- Python (Flask)
- HTML/CSS/JavaScript
